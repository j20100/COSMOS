#!/bin/bash
set -e
. activate keras-ros
